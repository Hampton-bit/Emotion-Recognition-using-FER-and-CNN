# B-FacialEmotionRecognition-Talha
This is a semester project in which I use CNNs to determine the emotion that a photo gives
